package ani.saikou.media

import android.app.Activity
import android.os.Handler
import android.os.Looper
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import ani.saikou.connections.anilist.Anilist
import ani.saikou.media.anime.Episode
import ani.saikou.media.anime.SelectorDialogFragment
import ani.saikou.loadData
import ani.saikou.logger
import ani.saikou.media.manga.MangaChapter
import ani.saikou.others.Jikan
import ani.saikou.parsers.Book
import ani.saikou.parsers.MangaImage
import ani.saikou.parsers.MangaReadSources
import ani.saikou.parsers.NovelSources
import ani.saikou.parsers.ShowResponse
import ani.saikou.parsers.VideoExtractor
import ani.saikou.parsers.WatchSources
import ani.saikou.saveData
import ani.saikou.snackString
import ani.saikou.tryWithSuspend
import ani.saikou.currContext
import ani.saikou.R
import ani.saikou.others.TheMovieDatabase
import ani.saikou.FileUrl
import com.bumptech.glide.load.resource.bitmap.BitmapTransformation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class MediaDetailsViewModel : ViewModel() {
    val scrolledToTop = MutableLiveData(true)

    fun saveSelected(id: Int, data: Selected, activity: Activity? = null) {
        saveData("$id-select", data, activity)
    }

    fun loadSelected(media: Media): Selected {
        return loadData<Selected>("${media.id}-select") ?: Selected().let {
            it.source = if (media.isAdult) 0 else when (media.anime != null) {
                true -> loadData("settings_def_anime_source") ?: 0
                else -> loadData("settings_def_manga_source") ?: 0
            }
            it.preferDub = loadData("settings_prefer_dub") ?: false
            saveSelected(media.id, it)
            it
        }
    }

    var continueMedia: Boolean? = null
    private var loading = false

    private val media: MutableLiveData<Media> = MutableLiveData<Media>(null)
    fun getMedia(): LiveData<Media> = media
    fun loadMedia(m: Media) {
        if (!loading) {
            loading = true
            viewModelScope.launch(Dispatchers.IO) {
                val mediaDetails = Anilist.query.mediaDetails(m)
                media.postValue(mediaDetails)
                launch {
                    try {
                        if (mediaDetails.anime != null) {
                            loadTmdbEpisodes(mediaDetails)
                        }
                    } catch (e: Exception) {
                        logger("Failed to load TMDB episodes: ${e.message}", true)
                    }
                }

                launch {
                    try {
                        if (mediaDetails.anime != null) {
                            loadFillerEpisodes(mediaDetails)
                        }
                    } catch (e: Exception) {
                        logger("Failed to load filler episodes: ${e.message}", true)
                    }
                }

                loading = false
            }
        }
    }

    fun setMedia(m: Media) {
        media.postValue(m)
    }

    val responses = MutableLiveData<List<ShowResponse>?>(null)

    private var tmdbEpisodesMediaId: Int? = null
    private val tmdbEpisodes: MutableLiveData<Map<String, Episode>> = MutableLiveData<Map<String, Episode>>(null)
    fun getTmdbEpisodes(): LiveData<Map<String, Episode>> = tmdbEpisodes

    suspend fun loadTmdbEpisodes(s: Media) {
        tryWithSuspend {
            val needsLoad = tmdbEpisodesMediaId != s.id || tmdbEpisodes.value.isNullOrEmpty()

            if (needsLoad) {
                val result = TheMovieDatabase.getTmdbEpisodesDetails(s)
                if (!result.isNullOrEmpty()) {
                    tmdbEpisodesMediaId = s.id
                    tmdbEpisodes.postValue(result)
                    if (epsLoaded.isNotEmpty()) {
                        epsLoaded.values.forEach { applyMetadataToEpisodes(it, s) }
                        episodes.postValue(epsLoaded)
                    }
                }
            }
        }
    }

    private var fillerEpisodesMediaId: Int? = null
    private val fillerEpisodes: MutableLiveData<Map<String, Episode>> = MutableLiveData<Map<String, Episode>>(null)
    fun getFillerEpisodes(): LiveData<Map<String, Episode>> = fillerEpisodes

    suspend fun loadFillerEpisodes(s: Media) {
        tryWithSuspend {
            val malId = s.idMAL ?: return@tryWithSuspend
            val needsLoad = fillerEpisodesMediaId != malId || fillerEpisodes.value == null

            if (needsLoad) {
                val result = Jikan.getEpisodes(malId)
                if (!result.isNullOrEmpty()) {
                    fillerEpisodesMediaId = malId
                    fillerEpisodes.postValue(result)
                    if (epsLoaded.isNotEmpty()) {
                        epsLoaded.values.forEach { applyMetadataToEpisodes(it, s) }
                        episodes.postValue(epsLoaded)
                    }
                }
            }
        }
    }

    private fun applyMetadataToEpisodes(
        episodes: MutableMap<String, Episode>,
        media: Media
    ) {
        val tmdb = tmdbEpisodes.value
        val filler = fillerEpisodes.value

        episodes.forEach { (num, ep) ->
            filler?.get(num)?.let { f ->
                ep.title = ep.title ?: f.title
                ep.filler = f.filler
            }
            tmdb?.get(num)?.let { t ->
                if (!t.title.isNullOrBlank()) ep.title = t.title
                if (!t.desc.isNullOrBlank())  ep.desc  = t.desc
                if (t.thumb != null) {
                    ep.thumb = t.thumb
                } else if (ep.thumb == null) {
                    ep.thumb = FileUrl[media.cover]
                }
                ep.seasonNumber = t.seasonNumber ?: ep.seasonNumber
                ep.seasonEpisodeNumber = t.seasonEpisodeNumber
            }
        }
    }

    var watchSources: WatchSources? = null

    private val episodes = MutableLiveData<MutableMap<Int, MutableMap<String, Episode>>>(null)
    private val epsLoaded = mutableMapOf<Int, MutableMap<String, Episode>>()
    fun getEpisodes(): LiveData<MutableMap<Int, MutableMap<String, Episode>>> = episodes

    suspend fun loadEpisodes(media: Media, i: Int) {
        if (!epsLoaded.containsKey(i)) {
            epsLoaded[i] = watchSources?.loadEpisodesFromMedia(i, media) ?: return
        }
        applyMetadataToEpisodes(epsLoaded[i]!!, media)
        episodes.postValue(epsLoaded)
    }

    suspend fun forceLoadEpisode(media: Media, i: Int) {
        epsLoaded[i] = watchSources?.loadEpisodesFromMedia(i, media) ?: return
        applyMetadataToEpisodes(epsLoaded[i]!!, media)
        episodes.postValue(epsLoaded)
    }

    suspend fun overrideEpisodes(i: Int, source: ShowResponse, id: Int) {
        watchSources?.saveResponse(i, id, source)
        epsLoaded[i] = watchSources?.loadEpisodes(i, source.link, source.extra) ?: return
        media.value?.let { applyMetadataToEpisodes(epsLoaded[i]!!, it) }
        episodes.postValue(epsLoaded)
    }

    private var episode = MutableLiveData<Episode?>(null)
    fun getEpisode(): LiveData<Episode?> = episode

    suspend fun loadEpisodeVideos(ep: Episode, i: Int, post: Boolean = true) {
        val link = ep.link ?: return
        if (!ep.allStreams || ep.extractors.isNullOrEmpty()) {
            val list = mutableListOf<VideoExtractor>()
            ep.extractors = list
            watchSources?.get(i)?.apply {
                if (!post && !allowsPreloading) return@apply
                loadByVideoServers(link, ep.extra) {
                    if (it.videos.isNotEmpty()) {
                        list.add(it)
                        ep.extractorCallback?.invoke(it)
                    }
                }
                ep.extractorCallback = null
                if (list.isNotEmpty())
                    ep.allStreams = true
            }
        }

        if (post) {
            episode.postValue(ep)
            MainScope().launch(Dispatchers.Main) {
                episode.value = null
            }
        }
    }

    suspend fun loadEpisodeSingleVideo(ep: Episode, selected: Selected, post: Boolean = true): Boolean {
        if (ep.extractors.isNullOrEmpty()) {
            val server = selected.server ?: return false
            val link = ep.link ?: return false

            ep.extractors = mutableListOf(watchSources?.get(selected.source)?.let {
                if (!post && !it.allowsPreloading) null
                else it.loadSingleVideoServer(server, link, ep.extra, post)
            } ?: return false)
            ep.allStreams = false
        }
        if (post) {
            episode.postValue(ep)
            MainScope().launch(Dispatchers.Main) {
                episode.value = null
            }
        }
        return true
    }

    fun setEpisode(ep: Episode?, who: String) {
        logger("set episode ${ep?.number} - $who", false)
        episode.postValue(ep)
        MainScope().launch(Dispatchers.Main) {
            episode.value = null
        }
    }

    val epChanged = MutableLiveData(true)
    fun onEpisodeClick(media: Media, i: String, manager: FragmentManager, launch: Boolean = true, prevEp: String? = null) {
        Handler(Looper.getMainLooper()).post {
            if (manager.findFragmentByTag("dialog") == null && !manager.isDestroyed) {
                if (media.anime?.episodes?.get(i) != null) {
                    media.anime.selectedEpisode = i
                } else {
                    snackString(currContext()?.getString(R.string.episode_not_found, i))
                    return@post
                }
                media.selected = this.loadSelected(media)
                val selector = SelectorDialogFragment.newInstance(media.selected!!.server, launch, prevEp)
                selector.show(manager, "dialog")
            }
        }
    }

    //Manga
    var mangaReadSources: MangaReadSources? = null

    private val mangaChapters = MutableLiveData<MutableMap<Int, MutableMap<String, MangaChapter>>>(null)
    private val mangaLoaded = mutableMapOf<Int, MutableMap<String, MangaChapter>>()
    fun getMangaChapters(): LiveData<MutableMap<Int, MutableMap<String, MangaChapter>>> = mangaChapters
    suspend fun loadMangaChapters(media: Media, i: Int) {
        logger("Loading Manga Chapters : $mangaLoaded")
        if (!mangaLoaded.containsKey(i)) tryWithSuspend {
            mangaLoaded[i] = mangaReadSources?.loadChaptersFromMedia(i, media) ?: return@tryWithSuspend
        }
        mangaChapters.postValue(mangaLoaded)
    }

    suspend fun overrideMangaChapters(i: Int, source: ShowResponse, id: Int) {
        mangaReadSources?.saveResponse(i, id, source)
        tryWithSuspend {
            mangaLoaded[i] = mangaReadSources?.loadChapters(i, source) ?: return@tryWithSuspend
        }
        mangaChapters.postValue(mangaLoaded)
    }

    private val mangaChapter = MutableLiveData<MangaChapter?>(null)
    fun getMangaChapter(): LiveData<MangaChapter?> = mangaChapter
    suspend fun loadMangaChapterImages(chapter: MangaChapter, selected: Selected, post: Boolean = true): Boolean {
        return tryWithSuspend(true) {
            chapter.addImages(
                mangaReadSources?.get(selected.source)?.loadImages(chapter.link) ?: return@tryWithSuspend false
            )
            if (post) mangaChapter.postValue(chapter)
            true
        } ?: false
    }

    fun loadTransformation(mangaImage: MangaImage, source: Int): BitmapTransformation? {
        return if (mangaImage.useTransformation) mangaReadSources?.get(source)?.getTransformation() else null
    }

    val novelSources = NovelSources
    val novelResponses = MutableLiveData<List<ShowResponse>>(null)
    suspend fun searchNovels(query: String, i: Int) {
        val source = novelSources[i]
        tryWithSuspend(post = true) {
            novelResponses.postValue(source.search(query))
        }
    }

    suspend fun autoSearchNovels(media: Media) {
        val source = novelSources[media.selected?.source ?: 0]
        tryWithSuspend(post = true) {
            novelResponses.postValue(source.sortedSearch(media))
        }
    }

    val book: MutableLiveData<Book> = MutableLiveData(null)
    suspend fun loadBook(novel: ShowResponse, i: Int) {
        tryWithSuspend {
            book.postValue(novelSources[i].loadBook(novel.link, novel.extra))
        }
    }
}