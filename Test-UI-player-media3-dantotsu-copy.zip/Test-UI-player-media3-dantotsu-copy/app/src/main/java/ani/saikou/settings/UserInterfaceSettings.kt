package ani.saikou.settings

import java.io.Serializable

data class UserInterfaceSettings(
    var darkMode: Boolean? = null,
    var showYtButton: Boolean = false,
    var animeDefaultView: Int = 0,
    var mangaDefaultView: Int = 0,

    //App
    var immersiveMode: Boolean = false,
    var smallView: Boolean = true,
    var defaultStartUpTab: Int = 0,
    var homeLayoutShow: MutableList<Boolean> = mutableListOf(true, false, false, true, false, false, true),

    //Animations
    var bannerAnimations: Boolean = true,
    var layoutAnimations: Boolean = true,
    var animationSpeed: Float = 1f

) : Serializable